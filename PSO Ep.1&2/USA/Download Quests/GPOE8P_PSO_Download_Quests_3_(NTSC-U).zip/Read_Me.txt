
This .zip archive contains the following NTSC-U Phantasy Star Online Ep. I & II
download quests in .gci format:

English

8P-GPOE-PSO______004.gci - Beach Laughter:2-2           (.bin file, Ep2, eng.)
8P-GPOE-PSO______005.gci - Beach Laughter:2-1           (.dat file, Ep2, eng.)
8P-GPOE-PSO______006.gci - Blue Star Memories:2-2       (.bin file, Ep2, eng.)
8P-GPOE-PSO______007.gci - Blue Star Memories:2-1       (.dat file, Ep2, eng.)
8P-GPOE-PSO______008.gci - Central Dome Fire Swirl:1-2  (.bin file, Ep1, eng.)
8P-GPOE-PSO______009.gci - Central Dome Fire Swirl:1-1  (.dat file, Ep1, eng.)
8P-GPOE-PSO______010.gci - Dream Messenger:2-2          (.bin file, Ep2, eng.)
8P-GPOE-PSO______011.gci - Dream Messenger:2-1          (.dat file, Ep2, eng.)
8P-GPOE-PSO______012.gci - Endless Nightmare #1:1-2     (.bin file, Ep1, eng.)
8P-GPOE-PSO______013.gci - Endless Nightmare #1:1-1     (.dat file, Ep1, eng.)
8P-GPOE-PSO______014.gci - Endless Nightmare #2:1-2     (.bin file, Ep1, eng.)
8P-GPOE-PSO______015.gci - Endless Nightmare #2:1-1     (.dat file, Ep1, eng.)
8P-GPOE-PSO______016.gci - Endless Nightmare #3:1-2     (.bin file, Ep1, eng.)
8P-GPOE-PSO______017.gci - Endless Nightmare #3:1-1     (.dat file, Ep1, eng.)
8P-GPOE-PSO______018.gci - Endless Nightmare #4:1-2     (.bin file, Ep1, eng.)
8P-GPOE-PSO______019.gci - Endless Nightmare #4:1-1     (.dat file, Ep1, eng.)
8P-GPOE-PSO______020.gci - Gallon's Shop:2-2            (.bin file, Ep2, eng.)
8P-GPOE-PSO______021.gci - Gallon's Shop:2-1            (.dat file, Ep2, eng.)
8P-GPOE-PSO______022.gci - Lost HEAT SWORD:1-2          (.bin file, Ep1, eng.)
8P-GPOE-PSO______023.gci - Lost HEAT SWORD:1-1          (.dat file, Ep1, eng.)
8P-GPOE-PSO______024.gci - Lost ICE SPINNER:1-2         (.bin file, Ep1, eng.)
8P-GPOE-PSO______025.gci - Lost ICE SPINNER:1-1         (.dat file, Ep1, eng.)
8P-GPOE-PSO______026.gci - Lost SOUL BLADE:1-2          (.bin file, Ep1, eng.)
8P-GPOE-PSO______027.gci - Lost SOUL BLADE:1-1          (.dat file, Ep1, eng.)
8P-GPOE-PSO______028.gci - Maximum Attack 1 v2:1-2      (.bin file, Ep1, eng.)
8P-GPOE-PSO______029.gci - Maximum Attack 1 v2:1-1      (.dat file, Ep1, eng.)
8P-GPOE-PSO______030.gci - Maximum Attack 2 v2:2-2      (.bin file, Ep2, eng.)
8P-GPOE-PSO______031.gci - Maximum Attack 2 v2:2-1      (.dat file, Ep2, eng.)
8P-GPOE-PSO______032.gci - Mop-up Operation #1:1-2      (.bin file, Ep1, eng.)
8P-GPOE-PSO______033.gci - Mop-up Operation #1:1-1      (.dat file, Ep1, eng.)
8P-GPOE-PSO______034.gci - Mop-up Operation #2:1-2      (.bin file, Ep1, eng.)
8P-GPOE-PSO______035.gci - Mop-up Operation #2:1-1      (.dat file, Ep1, eng.)
8P-GPOE-PSO______036.gci - Mop-up Operation #3:1-2      (.bin file, Ep1, eng.)
8P-GPOE-PSO______037.gci - Mop-up Operation #3:1-1      (.dat file, Ep1, eng.)
8P-GPOE-PSO______038.gci - Mop-up Operation #4:1-2      (.bin file, Ep1, eng.)
8P-GPOE-PSO______039.gci - Mop-up Operation #4:1-1      (.dat file, Ep1, eng.)
8P-GPOE-PSO______040.gci - Phantasmal World #1:2-2      (.bin file, Ep2, eng.)
8P-GPOE-PSO______041.gci - Phantasmal World #1:2-1      (.dat file, Ep2, eng.)
8P-GPOE-PSO______042.gci - Phantasmal World #2:2-2      (.bin file, Ep2, eng.)
8P-GPOE-PSO______043.gci - Phantasmal World #2:2-1      (.dat file, Ep2, eng.)
8P-GPOE-PSO______044.gci - Phantasmal World #3:2-2      (.bin file, Ep2, eng.)
8P-GPOE-PSO______045.gci - Phantasmal World #3:2-1      (.dat file, Ep2, eng.)
8P-GPOE-PSO______046.gci - Phantasmal World #4:2-2      (.bin file, Ep2, eng.)
8P-GPOE-PSO______047.gci - Phantasmal World #4:2-1      (.dat file, Ep2, eng.)
8P-GPOE-PSO______048.gci - Pioneer Christmas:2-2        (.bin file, Ep2, eng.)
8P-GPOE-PSO______049.gci - Pioneer Christmas:2-1        (.dat file, Ep2, eng.)
8P-GPOE-PSO______050.gci - Rappy's Holiday:1-2          (.bin file, Ep1, eng.)
8P-GPOE-PSO______051.gci - Rappy's Holiday:1-1          (.dat file, Ep1, eng.)
8P-GPOE-PSO______052.gci - Reach for the Dream:2-2      (.bin file, Ep2, eng.)
8P-GPOE-PSO______053.gci - Reach for the Dream:2-1      (.dat file, Ep2, eng.)
8P-GPOE-PSO______054.gci - Respective Tomorrow:2-2      (.bin file, Ep2, eng.)
8P-GPOE-PSO______055.gci - Respective Tomorrow:2-1      (.dat file, Ep2, eng.)
8P-GPOE-PSO______056.gci - Seat of the Heart:2-2        (.bin file, Ep2, eng.)
8P-GPOE-PSO______057.gci - Seat of the Heart:2-1        (.dat file, Ep2, eng.)
8P-GPOE-PSO______058.gci - St. Valentine's Day:1-2      (.bin file, Ep1, eng.)
8P-GPOE-PSO______059.gci - St. Valentine's Day:1-1      (.dat file, Ep1, eng.)
8P-GPOE-PSO______060.gci - The East Tower:2-2           (.bin file, Ep2, eng.)
8P-GPOE-PSO______061.gci - The East Tower:2-1           (.dat file, Ep2, eng.)
8P-GPOE-PSO______062.gci - The West Tower:2-2           (.bin file, Ep2, eng.)
8P-GPOE-PSO______063.gci - The West Tower:2-1           (.dat file, Ep2, eng.)
8P-GPOE-PSO______064.gci - Today's Rate:1-2             (.bin file, Ep1, eng.)
8P-GPOE-PSO______065.gci - Today's Rate:1-1             (.dat file, Ep1, eng.)
8P-GPOE-PSO______066.gci - Towards the Future:1-2       (.bin file, Ep1, eng.)
8P-GPOE-PSO______067.gci - Towards the Future:1-1       (.dat file, Ep1, eng.)
8P-GPOE-PSO______068.gci - White Day:1-2                (.bin file, Ep1, eng.)
8P-GPOE-PSO______069.gci - White Day:1-1                (.dat file, Ep1, eng.)
8P-GPOE-PSO______070.gci - Christmas Fiasco 1:1-2       (.bin file, Ep1, eng.)
8P-GPOE-PSO______071.gci - Christmas Fiasco 1:1-1       (.dat file, Ep1, eng.)
8P-GPOE-PSO______072.gci - Christmas Fiasco 2:2-2       (.bin file, Ep2, eng.)
8P-GPOE-PSO______073.gci - Christmas Fiasco 2:2-1       (.dat file, Ep2, eng.)
8P-GPOE-PSO______074.gci - Create Item V1.734:1-2       (.bin file, Ep1, eng.)
8P-GPOE-PSO______075.gci - Create Item V1.734:1-1       (.dat file, Ep1, eng.)
8P-GPOE-PSO______076.gci - Land of Lily:1-2             (.bin file, Ep1, eng.)
8P-GPOE-PSO______077.gci - Land of Lily:1-1             (.dat file, Ep1, eng.)
8P-GPOE-PSO______078.gci - Lost DEVIL'S SCEPTER:2-2     (.bin file, Ep2, eng.)
8P-GPOE-PSO______079.gci - Lost DEVIL'S SCEPTER:2-1     (.dat file, Ep2, eng.)
8P-GPOE-PSO______080.gci - Lost RIOT RAYGUN:2-2         (.bin file, Ep2, eng.)
8P-GPOE-PSO______081.gci - Lost RIOT RAYGUN:2-1         (.dat file, Ep2, eng.)
8P-GPOE-PSO______082.gci - Lost SHOCK GUNGNIR:2-2       (.bin file, Ep2, eng.)
8P-GPOE-PSO______083.gci - Lost SHOCK GUNGNIR:2-1       (.dat file, Ep2, eng.)
8P-GPOE-PSO______084.gci - Maximum Attack S:2-2         (.bin file, Ep2, eng.)
8P-GPOE-PSO______085.gci - Maximum Attack S:2-1         (.dat file, Ep2, eng.)
8P-GPOE-PSO______086.gci - Rare Rappies:2-2             (.bin file, Ep2, eng.)
8P-GPOE-PSO______087.gci - Rare Rappies:2-1             (.dat file, Ep2, eng.)
8P-GPOE-PSO______088.gci - Science Project:1-2          (.bin file, Ep1, eng.)
8P-GPOE-PSO______089.gci - Science Project:1-1          (.dat file, Ep1, eng.)
8P-GPOE-PSO______090.gci - Slime Anarchy:1-2            (.bin file, Ep1, eng.)
8P-GPOE-PSO______091.gci - Slime Anarchy:1-1            (.dat file, Ep1, eng.)
8P-GPOE-PSO______092.gci - The Tinkerbell's Dog 2:1-2   (.bin file, Ep1, eng.)
8P-GPOE-PSO______093.gci - The Tinkerbell's Dog 2:1-1   (.dat file, Ep1, eng.)
8P-GPOE-PSO______094.gci - Wrath of Forest:1-2          (.bin file, Ep1, eng.)
8P-GPOE-PSO______095.gci - Wrath of Forest:1-1          (.dat file, Ep1, eng.)

Note that you must always copy both download quest files (the .bin file and the
.dat file) to your memory card.

All download quest files in this archive are in unencrypted PRS compressed form
and are playable on every NTSC-U copy of the game with the following enabler
cheat code:

NTSC-U Phantasy Star Online Episode I & II (Version 1.00 & 1.01)
================================================================

Action Replay code format
-------------------------

Download Quests: PRS Compression Enabler [Ralf]
XMUH-WMCZ-HE05X
NV23-VP85-5W0W3
829P-J73K-XDQ39
TJHT-V175-CV0RA
NEZT-QZEZ-ZBAYN
66NH-MJVP-ZC6WC
96TQ-50VD-FGRTX
Z30Z-M5WM-BADV7
DC6J-E9QE-RQ8C3
8RC1-7E55-JW0Q8
4NPY-W08W-YDRZH
KBQE-UGX8-02UEN
9F4V-NGCJ-YR844
AK51-UP60-G747Q
8K4W-1KFA-H9X8W
UVXV-XKPV-9RHY4
ZDDA-QU40-A13MV
Y3P7-EB50-GYFFB
V6JM-YVHU-DJUA8
21Q5-UBBZ-RDF4A
1BDV-A0FC-P57ZV
91V3-TQ2X-AXA4A
E9FZ-A3QA-YCERP

Gecko/WiiRD code format
-----------------------

Download Quests: PRS Compression Enabler [Ralf]
20218318 807F0024
0600AFD0 00000034
801CFFF8 28000000
4182000C 38610010
480EE784 480EE7A0
7CA802A6 4820DF61
80610060 80030000
28000000 7CA803A6
4E800020 00000000
040F9760 4BF11870
04217A04 4BDF35E5
04217A08 41820060
04217F80 4BDF3069
04217F84 41820060
0421859C 4BDF2A4D
042185A0 41820044
E2000001 80008000


NTSC-U Phantasy Star Online Episode I & II Plus (Version 1.02)
==============================================================

Action Replay code format
-------------------------

Download Quests: PRS Compression Enabler [Ralf]
BEN8-D31R-BQ7PE
PTVA-W9NU-9R0NV
829P-J73K-XDQ39
TJHT-V175-CV0RA
NEZT-QZEZ-ZBAYN
66NH-MJVP-ZC6WC
UTA3-NNKA-BQQE8
NUR5-6E7D-5Z9Q9
DC6J-E9QE-RQ8C3
VX2R-BPNH-QED2T
4NPY-W08W-YDRZH
KBQE-UGX8-02UEN
9F4V-NGCJ-YR844
AK51-UP60-G747Q
8K4W-1KFA-H9X8W
8BK4-7C6X-DFRWE
QXG2-T968-BZNWJ
ZBH1-EVBQ-WZTTD
PW9G-MV61-UXWJQ
Z35Y-5KX9-W0W78
3ZEY-304P-6P8PW
V30D-1D6X-PUADA
E9FZ-A3QA-YCERP

Gecko/WiiRD code format
-----------------------

Download Quests: PRS Compression Enabler [Ralf]
202192A0 807F0024
0600AFD0 00000034
801CFFF8 28000000
4182000C 38610010
480EE66C 480EE688
7CA802A6 4820EEE9
80610060 80030000
28000000 7CA803A6
4E800020 00000000
040F9648 4BF11988
0421898C 4BDF265D
04218990 41820060
04218F08 4BDF20E1
04218F0C 41820060
04219524 4BDF1AC5
04219528 41820044
E2000001 80008000

