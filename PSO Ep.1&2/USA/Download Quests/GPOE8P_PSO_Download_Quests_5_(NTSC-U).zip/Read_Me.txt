
This .zip archive contains the following NTSC-U Phantasy Star Online Ep. I & II
download quests in .gci format:

Japanese

8P-GPOE-PSO______004.gci - AOL Cup Sunset Base:1-2      (.bin file, Ep1, jpn.)
8P-GPOE-PSO______005.gci - AOL Cup Sunset Base:1-1      (.dat file, Ep1, jpn.)
8P-GPOE-PSO______006.gci - Central Dome Fire Swirl:1-2  (.bin file, Ep1, jpn.)
8P-GPOE-PSO______007.gci - Central Dome Fire Swirl:1-1  (.dat file, Ep1, jpn.)
8P-GPOE-PSO______008.gci - Dungeons and Dragons:1-2     (.bin file, Ep1, jpn.)
8P-GPOE-PSO______009.gci - Dungeons and Dragons:1-1     (.dat file, Ep1, jpn.)
8P-GPOE-PSO______010.gci - EP1 Quest v1.4:1-2           (.bin file, Ep1, jpn.)
8P-GPOE-PSO______011.gci - EP1 Quest v1.4:1-1           (.dat file, Ep1, jpn.)
8P-GPOE-PSO______012.gci - Forest Offensive v1.10:1-2   (.bin file, Ep1, jpn.)
8P-GPOE-PSO______013.gci - Forest Offensive v1.10:1-1   (.dat file, Ep1, jpn.)
8P-GPOE-PSO______014.gci - Item Box Hunt:1-2            (.bin file, Ep1, jpn.)
8P-GPOE-PSO______015.gci - Item Box Hunt:1-1            (.dat file, Ep1, jpn.)
8P-GPOE-PSO______016.gci - Maximum Attack 4 2A:2-2      (.bin file, Ep2, jpn.)
8P-GPOE-PSO______017.gci - Maximum Attack 4 2A:2-1      (.dat file, Ep2, jpn.)
8P-GPOE-PSO______018.gci - Mericus Pwnage:2-2           (.bin file, Ep2, jpn.)
8P-GPOE-PSO______019.gci - Mericus Pwnage:2-1           (.dat file, Ep2, jpn.)
8P-GPOE-PSO______020.gci - Monster Bash 1:1-2           (.bin file, Ep1, jpn.)
8P-GPOE-PSO______021.gci - Monster Bash 1:1-1           (.dat file, Ep1, jpn.)
8P-GPOE-PSO______022.gci - Monster Bash 1 R:1-2         (.bin file, Ep1, jpn.)
8P-GPOE-PSO______023.gci - Monster Bash 1 R:1-1         (.dat file, Ep1, jpn.)
8P-GPOE-PSO______024.gci - Monster Bash 2:1-2           (.bin file, Ep1, jpn.)
8P-GPOE-PSO______025.gci - Monster Bash 2:1-1           (.dat file, Ep1, jpn.)
8P-GPOE-PSO______026.gci - Monster Bash 2 R:1-2         (.bin file, Ep1, jpn.)
8P-GPOE-PSO______027.gci - Monster Bash 2 R:1-1         (.dat file, Ep1, jpn.)
8P-GPOE-PSO______028.gci - Monster Bash 3:1-2           (.bin file, Ep1, jpn.)
8P-GPOE-PSO______029.gci - Monster Bash 3:1-1           (.dat file, Ep1, jpn.)
8P-GPOE-PSO______030.gci - Monster Bash 3 R:1-2         (.bin file, Ep1, jpn.)
8P-GPOE-PSO______031.gci - Monster Bash 3 R:1-1         (.dat file, Ep1, jpn.)
8P-GPOE-PSO______032.gci - Monster Bash 5:2-2           (.bin file, Ep2, jpn.)
8P-GPOE-PSO______033.gci - Monster Bash 5:2-1           (.dat file, Ep2, jpn.)
8P-GPOE-PSO______034.gci - Monster Bash 6:2-2           (.bin file, Ep2, jpn.)
8P-GPOE-PSO______035.gci - Monster Bash 6:2-1           (.dat file, Ep2, jpn.)
8P-GPOE-PSO______036.gci - PSO Famitsu Cup V2:1-2       (.bin file, Ep1, jpn.)
8P-GPOE-PSO______037.gci - PSO Famitsu Cup V2:1-1       (.dat file, Ep1, jpn.)
8P-GPOE-PSO______038.gci - Rappy Attack:2-2             (.bin file, Ep2, jpn.)
8P-GPOE-PSO______039.gci - Rappy Attack:2-1             (.dat file, Ep2, jpn.)
8P-GPOE-PSO______040.gci - Seat of the Heart:2-2        (.bin file, Ep2, jpn.)
8P-GPOE-PSO______041.gci - Seat of the Heart:2-1        (.dat file, Ep2, jpn.)
8P-GPOE-PSO______042.gci - Stage Quest Mines:1-2        (.bin file, Ep1, jpn.)
8P-GPOE-PSO______043.gci - Stage Quest Mines:1-1        (.dat file, Ep1, jpn.)
8P-GPOE-PSO______044.gci - The East Tower:2-2           (.bin file, Ep2, jpn.)
8P-GPOE-PSO______045.gci - The East Tower:2-1           (.dat file, Ep2, jpn.)
8P-GPOE-PSO______046.gci - The Fake in Blue:1-2         (.bin file, Ep1, jpn.)
8P-GPOE-PSO______047.gci - The Fake in Blue:1-1         (.dat file, Ep1, jpn.)
8P-GPOE-PSO______048.gci - The West Tower:2-2           (.bin file, Ep2, jpn.)
8P-GPOE-PSO______049.gci - The West Tower:2-1           (.dat file, Ep2, jpn.)
8P-GPOE-PSO______050.gci - TTF Version 1.5:1-2          (.bin file, Ep1, jpn.)
8P-GPOE-PSO______051.gci - TTF Version 1.5:1-1          (.dat file, Ep1, jpn.)
8P-GPOE-PSO______052.gci - Mine Offensive v1.02:1-2     (.bin file, Ep1, jpn.)
8P-GPOE-PSO______053.gci - Mine Offensive v1.02:1-1     (.dat file, Ep1, jpn.)
8P-GPOE-PSO______054.gci - Endless Forest Brawl 1:1-2   (.bin file, Ep1, jpn.)
8P-GPOE-PSO______055.gci - Endless Forest Brawl 1:1-1   (.dat file, Ep1, jpn.)

Note that you must always copy both download quest files (the .bin file and the
.dat file) to your memory card.

All download quest files in this archive are in unencrypted PRS compressed form
and are playable on every NTSC-U copy of the game with the following enabler
cheat code:

NTSC-U Phantasy Star Online Episode I & II (Version 1.00 & 1.01)
================================================================

Action Replay code format
-------------------------

Download Quests: PRS Compression Enabler [Ralf]
XMUH-WMCZ-HE05X
NV23-VP85-5W0W3
829P-J73K-XDQ39
TJHT-V175-CV0RA
NEZT-QZEZ-ZBAYN
66NH-MJVP-ZC6WC
96TQ-50VD-FGRTX
Z30Z-M5WM-BADV7
DC6J-E9QE-RQ8C3
8RC1-7E55-JW0Q8
4NPY-W08W-YDRZH
KBQE-UGX8-02UEN
9F4V-NGCJ-YR844
AK51-UP60-G747Q
8K4W-1KFA-H9X8W
UVXV-XKPV-9RHY4
ZDDA-QU40-A13MV
Y3P7-EB50-GYFFB
V6JM-YVHU-DJUA8
21Q5-UBBZ-RDF4A
1BDV-A0FC-P57ZV
91V3-TQ2X-AXA4A
E9FZ-A3QA-YCERP

Gecko/WiiRD code format
-----------------------

Download Quests: PRS Compression Enabler [Ralf]
20218318 807F0024
0600AFD0 00000034
801CFFF8 28000000
4182000C 38610010
480EE784 480EE7A0
7CA802A6 4820DF61
80610060 80030000
28000000 7CA803A6
4E800020 00000000
040F9760 4BF11870
04217A04 4BDF35E5
04217A08 41820060
04217F80 4BDF3069
04217F84 41820060
0421859C 4BDF2A4D
042185A0 41820044
E2000001 80008000


NTSC-U Phantasy Star Online Episode I & II Plus (Version 1.02)
==============================================================

Action Replay code format
-------------------------

Download Quests: PRS Compression Enabler [Ralf]
BEN8-D31R-BQ7PE
PTVA-W9NU-9R0NV
829P-J73K-XDQ39
TJHT-V175-CV0RA
NEZT-QZEZ-ZBAYN
66NH-MJVP-ZC6WC
UTA3-NNKA-BQQE8
NUR5-6E7D-5Z9Q9
DC6J-E9QE-RQ8C3
VX2R-BPNH-QED2T
4NPY-W08W-YDRZH
KBQE-UGX8-02UEN
9F4V-NGCJ-YR844
AK51-UP60-G747Q
8K4W-1KFA-H9X8W
8BK4-7C6X-DFRWE
QXG2-T968-BZNWJ
ZBH1-EVBQ-WZTTD
PW9G-MV61-UXWJQ
Z35Y-5KX9-W0W78
3ZEY-304P-6P8PW
V30D-1D6X-PUADA
E9FZ-A3QA-YCERP

Gecko/WiiRD code format
-----------------------

Download Quests: PRS Compression Enabler [Ralf]
202192A0 807F0024
0600AFD0 00000034
801CFFF8 28000000
4182000C 38610010
480EE66C 480EE688
7CA802A6 4820EEE9
80610060 80030000
28000000 7CA803A6
4E800020 00000000
040F9648 4BF11988
0421898C 4BDF265D
04218990 41820060
04218F08 4BDF20E1
04218F0C 41820060
04219524 4BDF1AC5
04219528 41820044
E2000001 80008000

