
This .zip archive contains the following NTSC-U Phantasy Star Online Ep. I & II
download quests in .gci format:

8P-GPOE-PSO______004.gci - Lost HEAT SWORD:1-2          (.bin file, Ep1, eng.)
8P-GPOE-PSO______005.gci - Lost HEAT SWORD:1-1          (.dat file, Ep1, eng.)
8P-GPOE-PSO______006.gci - Lost ICE SPINNER:1-2         (.bin file, Ep1, eng.)
8P-GPOE-PSO______007.gci - Lost ICE SPINNER:1-1         (.dat file, Ep1, eng.)
8P-GPOE-PSO______008.gci - Lost SOUL BLADE:1-2          (.bin file, Ep1, eng.)
8P-GPOE-PSO______009.gci - Lost SOUL BLADE:1-1          (.dat file, Ep1, eng.)
8P-GPOE-PSO______010.gci - Rappy's Holiday:1-2          (.bin file, Ep1, eng.)
8P-GPOE-PSO______011.gci - Rappy's Holiday:1-1          (.dat file, Ep1, eng.)
8P-GPOE-PSO______012.gci - Mop-up Operation 1:1-2       (.bin file, Ep1, eng.)
8P-GPOE-PSO______013.gci - Mop-up Operation 1:1-1       (.dat file, Ep1, eng.)
8P-GPOE-PSO______014.gci - Mop-up Operation 2:1-2       (.bin file, Ep1, eng.)
8P-GPOE-PSO______015.gci - Mop-up Operation 2:1-1       (.dat file, Ep1, eng.)
8P-GPOE-PSO______016.gci - Mop-up Operation 3:1-2       (.bin file, Ep1, eng.)
8P-GPOE-PSO______017.gci - Mop-up Operation 3:1-1       (.dat file, Ep1, eng.)
8P-GPOE-PSO______018.gci - Mop-up Operation 4:1-2       (.bin file, Ep1, eng.)
8P-GPOE-PSO______019.gci - Mop-up Operation 4:1-1       (.dat file, Ep1, eng.)
8P-GPOE-PSO______020.gci - Endless Nightmare 1:1-2      (.bin file, Ep1, eng.)
8P-GPOE-PSO______021.gci - Endless Nightmare 1:1-1      (.dat file, Ep1, eng.)
8P-GPOE-PSO______022.gci - Endless Nightmare 2:1-2      (.bin file, Ep1, eng.)
8P-GPOE-PSO______023.gci - Endless Nightmare 2:1-1      (.dat file, Ep1, eng.)
8P-GPOE-PSO______024.gci - Endless Nightmare 3:1-2      (.bin file, Ep1, eng.)
8P-GPOE-PSO______025.gci - Endless Nightmare 3:1-1      (.dat file, Ep1, eng.)
8P-GPOE-PSO______026.gci - Endless Nightmare 4:1-2      (.bin file, Ep1, eng.)
8P-GPOE-PSO______027.gci - Endless Nightmare 4:1-1      (.dat file, Ep1, eng.)
8P-GPOE-PSO______028.gci - Phantasmal World 1:2-2       (.bin file, Ep2, eng.)
8P-GPOE-PSO______029.gci - Phantasmal World 1:2-1       (.dat file, Ep2, eng.)
8P-GPOE-PSO______030.gci - Phantasmal World 2:2-2       (.bin file, Ep2, eng.)
8P-GPOE-PSO______031.gci - Phantasmal World 2:2-1       (.dat file, Ep2, eng.)
8P-GPOE-PSO______032.gci - Phantasmal World 3:2-2       (.bin file, Ep2, eng.)
8P-GPOE-PSO______033.gci - Phantasmal World 3:2-1       (.dat file, Ep2, eng.)
8P-GPOE-PSO______034.gci - Phantasmal World 4:2-2       (.bin file, Ep2, eng.)
8P-GPOE-PSO______035.gci - Phantasmal World 4:2-1       (.dat file, Ep2, eng.)
8P-GPOE-PSO______036.gci - Today's Rate:1-2             (.bin file, Ep1, eng.)
8P-GPOE-PSO______037.gci - Today's Rate:1-1             (.dat file, Ep1, eng.)
8P-GPOE-PSO______038.gci - Dream Messenger:2-2          (.bin file, Ep2, eng.)
8P-GPOE-PSO______039.gci - Dream Messenger:2-1          (.dat file, Ep2, eng.)
8P-GPOE-PSO______040.gci - Maximum Attack 2:2-2         (.bin file, Ep2, eng.)
8P-GPOE-PSO______041.gci - Maximum Attack 2:2-1         (.dat file, Ep2, eng.)
8P-GPOE-PSO______042.gci - Festivity on the Beach:2-2   (.bin file, Ep2, eng.)
8P-GPOE-PSO______043.gci - Festivity on the Beach:2-1   (.dat file, Ep2, eng.)
8P-GPOE-PSO______044.gci - Beach Laughter:2-2           (.bin file, Ep2, eng.)
8P-GPOE-PSO______045.gci - Beach Laughter:2-1           (.dat file, Ep2, eng.)
8P-GPOE-PSO______046.gci - St. Valentine's Day:1-2      (.bin file, Ep1, eng.)
8P-GPOE-PSO______047.gci - St. Valentine's Day:1-1      (.dat file, Ep1, eng.)
8P-GPOE-PSO______048.gci - The East Tower:2-2           (.bin file, Ep2, eng.)
8P-GPOE-PSO______049.gci - The East Tower:2-1           (.dat file, Ep2, eng.)
8P-GPOE-PSO______050.gci - White Day:1-2                (.bin file, Ep1, eng.)
8P-GPOE-PSO______051.gci - White Day:1-1                (.dat file, Ep1, eng.)
8P-GPOE-PSO______052.gci - Gallon's Shop:2-2            (.bin file, Ep2, eng.)
8P-GPOE-PSO______053.gci - Gallon's Shop:2-1            (.dat file, Ep2, eng.)
8P-GPOE-PSO______054.gci - Pioneer Warehouse:2-2        (.bin file, Ep2, eng.)
8P-GPOE-PSO______055.gci - Pioneer Warehouse:2-1        (.dat file, Ep2, eng.)
8P-GPOE-PSO______056.gci - Reach for the Dream:2-2      (.bin file, Ep2, eng.)
8P-GPOE-PSO______057.gci - Reach for the Dream:2-1      (.dat file, Ep2, eng.)
8P-GPOE-PSO______058.gci - Blue Star Memories:2-2       (.bin file, Ep2, eng.)
8P-GPOE-PSO______059.gci - Blue Star Memories:2-1       (.dat file, Ep2, eng.)
8P-GPOE-PSO______060.gci - Respective Tomorrow:2-2      (.bin file, Ep2, eng.)
8P-GPOE-PSO______061.gci - Respective Tomorrow:2-1      (.dat file, Ep2, eng.)
8P-GPOE-PSO______062.gci - Towards the Future:1-2       (.bin file, Ep1, eng.)
8P-GPOE-PSO______063.gci - Towards the Future:1-1       (.dat file, Ep1, eng.)
8P-GPOE-PSO______064.gci - Maximum Attack 1 v2:1-2      (.bin file, Ep1, eng.)
8P-GPOE-PSO______065.gci - Maximum Attack 1 v2:1-1      (.dat file, Ep1, eng.)
8P-GPOE-PSO______066.gci - Maximum Attack 2 v2:2-2      (.bin file, Ep2, eng.)
8P-GPOE-PSO______067.gci - Maximum Attack 2 v2:2-1      (.dat file, Ep2, eng.)
8P-GPOE-PSO______068.gci - Christmas Quest:2-2          (.bin file, Ep2, eng.)
8P-GPOE-PSO______069.gci - Christmas Quest:2-1          (.dat file, Ep2, eng.)
8P-GPOE-PSO______070.gci - Requiem:2-2                  (.bin file, Ep2, eng.)
8P-GPOE-PSO______071.gci - Requiem:2-1                  (.dat file, Ep2, eng.)
8P-GPOE-PSO______072.gci - The West Tower:2-2           (.bin file, Ep2, eng.)
8P-GPOE-PSO______073.gci - The West Tower:2-1           (.dat file, Ep2, eng.)
8P-GPOE-PSO______074.gci - Lost EGG BLASTER:1-2         (.bin file, Ep1, eng.)
8P-GPOE-PSO______075.gci - Lost EGG BLASTER:1-1         (.dat file, Ep1, eng.)
8P-GPOE-PSO______076.gci - Miyu's Nightmare:1-2         (.bin file, Ep1, eng.)
8P-GPOE-PSO______077.gci - Miyu's Nightmare:1-1         (.dat file, Ep1, eng.)
8P-GPOE-PSO______078.gci - Weather Effects:2-2          (.bin file, Ep2, eng.)
8P-GPOE-PSO______079.gci - Weather Effects:2-1          (.dat file, Ep2, eng.)
8P-GPOE-PSO______080.gci - Soulja Psotools:1-2          (.bin file, Ep1, eng.)
8P-GPOE-PSO______081.gci - Soulja Psotools:1-1          (.dat file, Ep1, eng.)
8P-GPOE-PSO______082.gci - Ill Gill Ownage:2-2          (.bin file, Ep2, eng.)
8P-GPOE-PSO______083.gci - Ill Gill Ownage:2-1          (.dat file, Ep2, eng.)
8P-GPOE-PSO______084.gci - Bossanova:1-2                (.bin file, Ep1, eng.)
8P-GPOE-PSO______085.gci - Bossanova:1-1                (.dat file, Ep1, eng.)
8P-GPOE-PSO______086.gci - Create Item V1.700:1-2       (.bin file, Ep1, eng.)
8P-GPOE-PSO______087.gci - Create Item V1.700:1-1       (.dat file, Ep1, eng.)
8P-GPOE-PSO______088.gci - The Construct:2-2            (.bin file, Ep2, eng.)
8P-GPOE-PSO______089.gci - The Construct:2-1            (.dat file, Ep2, eng.)
8P-GPOE-PSO______090.gci - Tower Quest:2-2              (.bin file, Ep2, eng.)
8P-GPOE-PSO______091.gci - Tower Quest:2-1              (.dat file, Ep2, eng.)

Note that you must always copy both download quest files (the .bin file and the
.dat file) to your memory card.

All download quest files in this archive have embedded decryption keys and are
playable on every NTSC-U copy of the game with the following enabler cheat code:

NTSC-U Phantasy Star Online Episode I & II (Version 1.00 & 1.01)
================================================================

Action Replay code format
-------------------------

Download Quests: Decryption Key Enabler [Ralf]
4A4W-ANN4-1UGZA
NV23-VP85-5W0W3
JJW6-34Q0-0UEXF
A7N6-M7FA-AVB9R
XDVX-84NU-6RMZ6
0E2N-CXU7-RPBR2
KZ0C-EDUW-7G6QJ
R4AH-QACV-9V4CV
D7ZZ-EW7R-YUVKK
Z2N7-Y6XQ-ZD8XZ
E9FZ-A3QA-YCERP

Gecko/WiiRD code format
-----------------------

Download Quests: Decryption Key Enabler [Ralf]
20218318 807F0024
0600B040 0000001C
807F2388 8063001C
28030000 4C820020
7FE3FB78 9421FFF0
4820C458 00000000
042174AC 4BDF3B94
E2000001 80008000


NTSC-U Phantasy Star Online Episode I & II Plus (Version 1.02)
==============================================================

Action Replay code format
-------------------------

Download Quests: Decryption Key Enabler [Ralf]
NE8K-XTQF-AQCPR
PTVA-W9NU-9R0NV
JJW6-34Q0-0UEXF
A7N6-M7FA-AVB9R
XDVX-84NU-6RMZ6
0E2N-CXU7-RPBR2
KZ0C-EDUW-7G6QJ
R4AH-QACV-9V4CV
YKRD-PTK3-H9YYG
C7KK-MB6M-064KY
E9FZ-A3QA-YCERP

Gecko/WiiRD code format
-----------------------

Download Quests: Decryption Key Enabler [Ralf]
202192A0 807F0024
0600B040 0000001C
807F2388 8063001C
28030000 4C820020
7FE3FB78 9421FFF0
4820D3DC 00000000
04218430 4BDF2C10
E2000001 80008000

