
This .zip archive contains the following PAL Phantasy Star Online Ep. I & II
download quests in .gci format:

Japanese

8P-GPOP-PSO______004.gci - AOL Cup Sunset Base:1-2      (.bin file, Ep1, jpn.)
8P-GPOP-PSO______005.gci - AOL Cup Sunset Base:1-1      (.dat file, Ep1, jpn.)
8P-GPOP-PSO______006.gci - Central Dome Fire Swirl:1-2  (.bin file, Ep1, jpn.)
8P-GPOP-PSO______007.gci - Central Dome Fire Swirl:1-1  (.dat file, Ep1, jpn.)
8P-GPOP-PSO______008.gci - Dungeons and Dragons:1-2     (.bin file, Ep1, jpn.)
8P-GPOP-PSO______009.gci - Dungeons and Dragons:1-1     (.dat file, Ep1, jpn.)
8P-GPOP-PSO______010.gci - EP1 Quest v1.4:1-2           (.bin file, Ep1, jpn.)
8P-GPOP-PSO______011.gci - EP1 Quest v1.4:1-1           (.dat file, Ep1, jpn.)
8P-GPOP-PSO______012.gci - Forest Offensive v1.10:1-2   (.bin file, Ep1, jpn.)
8P-GPOP-PSO______013.gci - Forest Offensive v1.10:1-1   (.dat file, Ep1, jpn.)
8P-GPOP-PSO______014.gci - Item Box Hunt:1-2            (.bin file, Ep1, jpn.)
8P-GPOP-PSO______015.gci - Item Box Hunt:1-1            (.dat file, Ep1, jpn.)
8P-GPOP-PSO______016.gci - Maximum Attack 4 2A:2-2      (.bin file, Ep2, jpn.)
8P-GPOP-PSO______017.gci - Maximum Attack 4 2A:2-1      (.dat file, Ep2, jpn.)
8P-GPOP-PSO______018.gci - Mericus Pwnage:2-2           (.bin file, Ep2, jpn.)
8P-GPOP-PSO______019.gci - Mericus Pwnage:2-1           (.dat file, Ep2, jpn.)
8P-GPOP-PSO______020.gci - Monster Bash 1:1-2           (.bin file, Ep1, jpn.)
8P-GPOP-PSO______021.gci - Monster Bash 1:1-1           (.dat file, Ep1, jpn.)
8P-GPOP-PSO______022.gci - Monster Bash 1 R:1-2         (.bin file, Ep1, jpn.)
8P-GPOP-PSO______023.gci - Monster Bash 1 R:1-1         (.dat file, Ep1, jpn.)
8P-GPOP-PSO______024.gci - Monster Bash 2:1-2           (.bin file, Ep1, jpn.)
8P-GPOP-PSO______025.gci - Monster Bash 2:1-1           (.dat file, Ep1, jpn.)
8P-GPOP-PSO______026.gci - Monster Bash 2 R:1-2         (.bin file, Ep1, jpn.)
8P-GPOP-PSO______027.gci - Monster Bash 2 R:1-1         (.dat file, Ep1, jpn.)
8P-GPOP-PSO______028.gci - Monster Bash 3:1-2           (.bin file, Ep1, jpn.)
8P-GPOP-PSO______029.gci - Monster Bash 3:1-1           (.dat file, Ep1, jpn.)
8P-GPOP-PSO______030.gci - Monster Bash 3 R:1-2         (.bin file, Ep1, jpn.)
8P-GPOP-PSO______031.gci - Monster Bash 3 R:1-1         (.dat file, Ep1, jpn.)
8P-GPOP-PSO______032.gci - Monster Bash 5:2-2           (.bin file, Ep2, jpn.)
8P-GPOP-PSO______033.gci - Monster Bash 5:2-1           (.dat file, Ep2, jpn.)
8P-GPOP-PSO______034.gci - Monster Bash 6:2-2           (.bin file, Ep2, jpn.)
8P-GPOP-PSO______035.gci - Monster Bash 6:2-1           (.dat file, Ep2, jpn.)
8P-GPOP-PSO______036.gci - PSO Famitsu Cup V2:1-2       (.bin file, Ep1, jpn.)
8P-GPOP-PSO______037.gci - PSO Famitsu Cup V2:1-1       (.dat file, Ep1, jpn.)
8P-GPOP-PSO______038.gci - Rappy Attack:2-2             (.bin file, Ep2, jpn.)
8P-GPOP-PSO______039.gci - Rappy Attack:2-1             (.dat file, Ep2, jpn.)
8P-GPOP-PSO______040.gci - Seat of the Heart:2-2        (.bin file, Ep2, jpn.)
8P-GPOP-PSO______041.gci - Seat of the Heart:2-1        (.dat file, Ep2, jpn.)
8P-GPOP-PSO______042.gci - Stage Quest Mines:1-2        (.bin file, Ep1, jpn.)
8P-GPOP-PSO______043.gci - Stage Quest Mines:1-1        (.dat file, Ep1, jpn.)
8P-GPOP-PSO______044.gci - The East Tower:2-2           (.bin file, Ep2, jpn.)
8P-GPOP-PSO______045.gci - The East Tower:2-1           (.dat file, Ep2, jpn.)
8P-GPOP-PSO______046.gci - The Fake in Blue:1-2         (.bin file, Ep1, jpn.)
8P-GPOP-PSO______047.gci - The Fake in Blue:1-1         (.dat file, Ep1, jpn.)
8P-GPOP-PSO______048.gci - The West Tower:2-2           (.bin file, Ep2, jpn.)
8P-GPOP-PSO______049.gci - The West Tower:2-1           (.dat file, Ep2, jpn.)
8P-GPOP-PSO______050.gci - TTF Version 1.5:1-2          (.bin file, Ep1, jpn.)
8P-GPOP-PSO______051.gci - TTF Version 1.5:1-1          (.dat file, Ep1, jpn.)
8P-GPOP-PSO______052.gci - Mine Offensive v1.02:1-2     (.bin file, Ep1, jpn.)
8P-GPOP-PSO______053.gci - Mine Offensive v1.02:1-1     (.dat file, Ep1, jpn.)
8P-GPOP-PSO______054.gci - Endless Forest Brawl 1:1-2   (.bin file, Ep1, jpn.)
8P-GPOP-PSO______055.gci - Endless Forest Brawl 1:1-1   (.dat file, Ep1, jpn.)

Note that you must always copy both download quest files (the .bin file and the
.dat file) to your memory card.

All download quest files in this archive are in unencrypted PRS compressed form
and are playable on every PAL copy of the game with the following enabler cheat
code:

PAL Phantasy Star Online Episode I & II
=======================================

Action Replay code format
-------------------------

Download Quests: PRS Compression Enabler [Ralf]
V9EM-QZPN-P7KCD
0U3N-81R8-UVUXB
829P-J73K-XDQ39
TJHT-V175-CV0RA
NEZT-QZEZ-ZBAYN
66NH-MJVP-ZC6WC
X6CC-4BBX-KJ00A
3MV8-A8T3-8DFQG
DC6J-E9QE-RQ8C3
G2HK-N7EM-BJUAF
4NPY-W08W-YDRZH
KBQE-UGX8-02UEN
9F4V-NGCJ-YR844
AK51-UP60-G747Q
8K4W-1KFA-H9X8W
GUMK-4BZZ-VRGD4
WDZ4-HAW6-R6FR8
FH22-MKEH-YKPC3
FXMP-2VFJ-NJPQM
P43R-N3M0-ABR7Z
YBM9-UY5K-9FNWK
623K-39W1-G4PAD
E9FZ-A3QA-YCERP

Gecko/WiiRD code format
-----------------------

Download Quests: PRS Compression Enabler [Ralf]
20218C64 807F0024
0600AFD0 00000034
801CFFF8 28000000
4182000C 38610010
480EE85C 480EE878
7CA802A6 4820E8AD
80610060 80030000
28000000 7CA803A6
4E800020 00000000
040F9838 4BF11798
04218350 4BDF2C99
04218354 41820060
042188CC 4BDF271D
042188D0 41820060
04218EE8 4BDF2101
04218EEC 41820044
E2000001 80008000

