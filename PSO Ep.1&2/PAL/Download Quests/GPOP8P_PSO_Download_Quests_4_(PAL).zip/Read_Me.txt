
This .zip archive contains the following PAL Phantasy Star Online Ep. I & II
download quests in .gci format:

English

8P-GPOP-PSO______004.gci - A New Hope:2-2               (.bin file, Ep2, eng.)
8P-GPOP-PSO______005.gci - A New Hope:2-1               (.dat file, Ep2, eng.)
8P-GPOP-PSO______006.gci - Bossanova:1-2                (.bin file, Ep1, eng.)
8P-GPOP-PSO______007.gci - Bossanova:1-1                (.dat file, Ep1, eng.)
8P-GPOP-PSO______008.gci - Festivity on the Beach:2-2   (.bin file, Ep2, eng.)
8P-GPOP-PSO______009.gci - Festivity on the Beach:2-1   (.dat file, Ep2, eng.)
8P-GPOP-PSO______010.gci - Forsaken Friends:1-2         (.bin file, Ep1, eng.)
8P-GPOP-PSO______011.gci - Forsaken Friends:1-1         (.dat file, Ep1, eng.)
8P-GPOP-PSO______012.gci - Fragments of a Memory:1-2    (.bin file, Ep1, eng.)
8P-GPOP-PSO______013.gci - Fragments of a Memory:1-1    (.dat file, Ep1, eng.)
8P-GPOP-PSO______014.gci - Gallon's Treachery:1-2       (.bin file, Ep1, eng.)
8P-GPOP-PSO______015.gci - Gallon's Treachery:1-1       (.dat file, Ep1, eng.)
8P-GPOP-PSO______016.gci - Ill Gill Ownage:2-2          (.bin file, Ep2, eng.)
8P-GPOP-PSO______017.gci - Ill Gill Ownage:2-1          (.dat file, Ep2, eng.)
8P-GPOP-PSO______018.gci - Labyrinthine Trial:1-2       (.bin file, Ep1, eng.)
8P-GPOP-PSO______019.gci - Labyrinthine Trial:1-1       (.dat file, Ep1, eng.)
8P-GPOP-PSO______020.gci - Lost EGG BLASTER:1-2         (.bin file, Ep1, eng.)
8P-GPOP-PSO______021.gci - Lost EGG BLASTER:1-1         (.dat file, Ep1, eng.)
8P-GPOP-PSO______022.gci - Maximum Attack 2:2-2         (.bin file, Ep2, eng.)
8P-GPOP-PSO______023.gci - Maximum Attack 2:2-1         (.dat file, Ep2, eng.)
8P-GPOP-PSO______024.gci - Military Strikes Back:2-2    (.bin file, Ep2, eng.)
8P-GPOP-PSO______025.gci - Military Strikes Back:2-1    (.dat file, Ep2, eng.)
8P-GPOP-PSO______026.gci - Milla Hunt:1-2               (.bin file, Ep1, eng.)
8P-GPOP-PSO______027.gci - Milla Hunt:1-1               (.dat file, Ep1, eng.)
8P-GPOP-PSO______028.gci - Miyu's Nightmare:1-2         (.bin file, Ep1, eng.)
8P-GPOP-PSO______029.gci - Miyu's Nightmare:1-1         (.dat file, Ep1, eng.)
8P-GPOP-PSO______030.gci - Lost CHAOS CALIBUR:2-2       (.bin file, Ep2, eng.)
8P-GPOP-PSO______031.gci - Lost CHAOS CALIBUR:2-1       (.dat file, Ep2, eng.)
8P-GPOP-PSO______032.gci - Requiem:2-2                  (.bin file, Ep2, eng.)
8P-GPOP-PSO______033.gci - Requiem:2-1                  (.dat file, Ep2, eng.)
8P-GPOP-PSO______034.gci - Schthack Request:1-2         (.bin file, Ep1, eng.)
8P-GPOP-PSO______035.gci - Schthack Request:1-1         (.dat file, Ep1, eng.)
8P-GPOP-PSO______036.gci - Sealed J-Sword Hunt:2-2      (.bin file, Ep2, eng.)
8P-GPOP-PSO______037.gci - Sealed J-Sword Hunt:2-1      (.dat file, Ep2, eng.)
8P-GPOP-PSO______038.gci - Strange Sighting:1-2         (.bin file, Ep1, eng.)
8P-GPOP-PSO______039.gci - Strange Sighting:1-1         (.dat file, Ep1, eng.)
8P-GPOP-PSO______040.gci - The Missing Maracas:1-2      (.bin file, Ep1, eng.)
8P-GPOP-PSO______041.gci - The Missing Maracas:1-1      (.dat file, Ep1, eng.)
8P-GPOP-PSO______042.gci - The Principal's Gift:1-2     (.bin file, Ep1, eng.)
8P-GPOP-PSO______043.gci - The Principal's Gift:1-1     (.dat file, Ep1, eng.)
8P-GPOP-PSO______044.gci - Tower Mop Up:2-2             (.bin file, Ep2, eng.)
8P-GPOP-PSO______045.gci - Tower Mop Up:2-1             (.dat file, Ep2, eng.)
8P-GPOP-PSO______046.gci - Tyrell's Last Hope:1-2       (.bin file, Ep1, eng.)
8P-GPOP-PSO______047.gci - Tyrell's Last Hope:1-1       (.dat file, Ep1, eng.)
8P-GPOP-PSO______048.gci - Ultimate TTF:1-2             (.bin file, Ep1, eng.)
8P-GPOP-PSO______049.gci - Ultimate TTF:1-1             (.dat file, Ep1, eng.)
8P-GPOP-PSO______050.gci - Weather Effects:2-2          (.bin file, Ep2, eng.)
8P-GPOP-PSO______051.gci - Weather Effects:2-1          (.dat file, Ep2, eng.)
8P-GPOP-PSO______052.gci - Claire's Deal:1-2            (.bin file, Ep1, eng.)
8P-GPOP-PSO______053.gci - Claire's Deal:1-1            (.dat file, Ep1, eng.)
8P-GPOP-PSO______054.gci - Den of the Damned:2-2        (.bin file, Ep2, eng.)
8P-GPOP-PSO______055.gci - Den of the Damned:2-1        (.dat file, Ep2, eng.)
8P-GPOP-PSO______056.gci - Gal Da Val's Darkness:2-2    (.bin file, Ep2, eng.)
8P-GPOP-PSO______057.gci - Gal Da Val's Darkness:2-1    (.dat file, Ep2, eng.)
8P-GPOP-PSO______058.gci - Pioneer Warehouse:2-2        (.bin file, Ep2, eng.)
8P-GPOP-PSO______059.gci - Pioneer Warehouse:2-1        (.dat file, Ep2, eng.)
8P-GPOP-PSO______060.gci - Hazardous Dimension:1-2      (.bin file, Ep1, eng.)
8P-GPOP-PSO______061.gci - Hazardous Dimension:1-1      (.dat file, Ep1, eng.)
8P-GPOP-PSO______062.gci - Maximum Attack 4 2A:2-2      (.bin file, Ep2, eng.)
8P-GPOP-PSO______063.gci - Maximum Attack 4 2A:2-1      (.dat file, Ep2, eng.)
8P-GPOP-PSO______064.gci - Maximum Attack 4 2B:2-2      (.bin file, Ep2, eng.)
8P-GPOP-PSO______065.gci - Maximum Attack 4 2B:2-1      (.dat file, Ep2, eng.)
8P-GPOP-PSO______066.gci - Maximum Attack 4 2C:2-2      (.bin file, Ep2, eng.)
8P-GPOP-PSO______067.gci - Maximum Attack 4 2C:2-1      (.dat file, Ep2, eng.)
8P-GPOP-PSO______068.gci - Oceanic Invasion:2-2         (.bin file, Ep2, eng.)
8P-GPOP-PSO______069.gci - Oceanic Invasion:2-1         (.dat file, Ep2, eng.)
8P-GPOP-PSO______070.gci - Pioneer Halloween:2-2        (.bin file, Ep2, eng.)
8P-GPOP-PSO______071.gci - Pioneer Halloween:2-1        (.dat file, Ep2, eng.)
8P-GPOP-PSO______072.gci - Revisiting Darkness:2-2      (.bin file, Ep2, eng.)
8P-GPOP-PSO______073.gci - Revisiting Darkness:2-1      (.dat file, Ep2, eng.)
8P-GPOP-PSO______074.gci - Simulator v1.01:1-2          (.bin file, Ep1, eng.)
8P-GPOP-PSO______075.gci - Simulator v1.01:1-1          (.dat file, Ep1, eng.)
8P-GPOP-PSO______076.gci - Sister's Dream:2-2           (.bin file, Ep2, eng.)
8P-GPOP-PSO______077.gci - Sister's Dream:2-1           (.dat file, Ep2, eng.)
8P-GPOP-PSO______078.gci - Spirit of the Sun:2-2        (.bin file, Ep2, eng.)
8P-GPOP-PSO______079.gci - Spirit of the Sun:2-1        (.dat file, Ep2, eng.)
8P-GPOP-PSO______080.gci - The Fake in Blue:1-2         (.bin file, Ep1, eng.)
8P-GPOP-PSO______081.gci - The Fake in Blue:1-1         (.dat file, Ep1, eng.)
8P-GPOP-PSO______082.gci - TTF Enhanced:1-2             (.bin file, Ep1, eng.)
8P-GPOP-PSO______083.gci - TTF Enhanced:1-1             (.dat file, Ep1, eng.)
8P-GPOP-PSO______084.gci - Lost HEART BREAKER:2-2       (.bin file, Ep2, eng.)
8P-GPOP-PSO______085.gci - Lost HEART BREAKER:2-1       (.dat file, Ep2, eng.)
8P-GPOP-PSO______086.gci - Malicious Uprising #1:2-2    (.bin file, Ep2, eng.)
8P-GPOP-PSO______087.gci - Malicious Uprising #1:2-1    (.dat file, Ep2, eng.)
8P-GPOP-PSO______088.gci - Malicious Uprising #2:2-2    (.bin file, Ep2, eng.)
8P-GPOP-PSO______089.gci - Malicious Uprising #2:2-1    (.dat file, Ep2, eng.)
8P-GPOP-PSO______090.gci - Malicious Uprising #3:2-2    (.bin file, Ep2, eng.)
8P-GPOP-PSO______091.gci - Malicious Uprising #3:2-1    (.dat file, Ep2, eng.)
8P-GPOP-PSO______092.gci - Malicious Uprising #4:2-2    (.bin file, Ep2, eng.)
8P-GPOP-PSO______093.gci - Malicious Uprising #4:2-1    (.dat file, Ep2, eng.)
8P-GPOP-PSO______094.gci - Malicious Uprising #5:2-2    (.bin file, Ep2, eng.)
8P-GPOP-PSO______095.gci - Malicious Uprising #5:2-1    (.dat file, Ep2, eng.)

Note that you must always copy both download quest files (the .bin file and the
.dat file) to your memory card.

All download quest files in this archive are in unencrypted PRS compressed form
and are playable on every PAL copy of the game with the following enabler cheat
code:

PAL Phantasy Star Online Episode I & II
=======================================

Action Replay code format
-------------------------

Download Quests: PRS Compression Enabler [Ralf]
V9EM-QZPN-P7KCD
0U3N-81R8-UVUXB
829P-J73K-XDQ39
TJHT-V175-CV0RA
NEZT-QZEZ-ZBAYN
66NH-MJVP-ZC6WC
X6CC-4BBX-KJ00A
3MV8-A8T3-8DFQG
DC6J-E9QE-RQ8C3
G2HK-N7EM-BJUAF
4NPY-W08W-YDRZH
KBQE-UGX8-02UEN
9F4V-NGCJ-YR844
AK51-UP60-G747Q
8K4W-1KFA-H9X8W
GUMK-4BZZ-VRGD4
WDZ4-HAW6-R6FR8
FH22-MKEH-YKPC3
FXMP-2VFJ-NJPQM
P43R-N3M0-ABR7Z
YBM9-UY5K-9FNWK
623K-39W1-G4PAD
E9FZ-A3QA-YCERP

Gecko/WiiRD code format
-----------------------

Download Quests: PRS Compression Enabler [Ralf]
20218C64 807F0024
0600AFD0 00000034
801CFFF8 28000000
4182000C 38610010
480EE85C 480EE878
7CA802A6 4820E8AD
80610060 80030000
28000000 7CA803A6
4E800020 00000000
040F9838 4BF11798
04218350 4BDF2C99
04218354 41820060
042188CC 4BDF271D
042188D0 41820060
04218EE8 4BDF2101
04218EEC 41820044
E2000001 80008000

