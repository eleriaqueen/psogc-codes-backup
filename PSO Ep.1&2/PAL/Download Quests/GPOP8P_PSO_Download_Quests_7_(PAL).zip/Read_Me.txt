
This .zip archive contains the following PAL Phantasy Star Online Ep. I & II
download quests in .gci format:

French

8P-GPOP-PSO______004.gci - Central Dome Fire Swirl:1-2  (.bin file, Ep1, fre.)
8P-GPOP-PSO______005.gci - Central Dome Fire Swirl:1-1  (.dat file, Ep1, fre.)
8P-GPOP-PSO______006.gci - Dream Messenger:2-2          (.bin file, Ep2, fre.)
8P-GPOP-PSO______007.gci - Dream Messenger:2-1          (.dat file, Ep2, fre.)
8P-GPOP-PSO______008.gci - Endless Nightmare #1:1-2     (.bin file, Ep1, fre.)
8P-GPOP-PSO______009.gci - Endless Nightmare #1:1-1     (.dat file, Ep1, fre.)
8P-GPOP-PSO______010.gci - Endless Nightmare #2:1-2     (.bin file, Ep1, fre.)
8P-GPOP-PSO______011.gci - Endless Nightmare #2:1-1     (.dat file, Ep1, fre.)
8P-GPOP-PSO______012.gci - Endless Nightmare #3:1-2     (.bin file, Ep1, fre.)
8P-GPOP-PSO______013.gci - Endless Nightmare #3:1-1     (.dat file, Ep1, fre.)
8P-GPOP-PSO______014.gci - Endless Nightmare #4:1-2     (.bin file, Ep1, fre.)
8P-GPOP-PSO______015.gci - Endless Nightmare #4:1-1     (.dat file, Ep1, fre.)
8P-GPOP-PSO______016.gci - Gallon's Treachery:1-2       (.bin file, Ep1, fre.)
8P-GPOP-PSO______017.gci - Gallon's Treachery:1-1       (.dat file, Ep1, fre.)
8P-GPOP-PSO______018.gci - Labyrinthine Trial:1-2       (.bin file, Ep1, fre.)
8P-GPOP-PSO______019.gci - Labyrinthine Trial:1-1       (.dat file, Ep1, fre.)
8P-GPOP-PSO______020.gci - Lost HEAT SWORD:1-2          (.bin file, Ep1, fre.)
8P-GPOP-PSO______021.gci - Lost HEAT SWORD:1-1          (.dat file, Ep1, fre.)
8P-GPOP-PSO______022.gci - Lost ICE SPINNER:1-2         (.bin file, Ep1, fre.)
8P-GPOP-PSO______023.gci - Lost ICE SPINNER:1-1         (.dat file, Ep1, fre.)
8P-GPOP-PSO______024.gci - Lost SOUL BLADE:1-2          (.bin file, Ep1, fre.)
8P-GPOP-PSO______025.gci - Lost SOUL BLADE:1-1          (.dat file, Ep1, fre.)
8P-GPOP-PSO______026.gci - Mop-up Operation #1:1-2      (.bin file, Ep1, fre.)
8P-GPOP-PSO______027.gci - Mop-up Operation #1:1-1      (.dat file, Ep1, fre.)
8P-GPOP-PSO______028.gci - Mop-up Operation #2:1-2      (.bin file, Ep1, fre.)
8P-GPOP-PSO______029.gci - Mop-up Operation #2:1-1      (.dat file, Ep1, fre.)
8P-GPOP-PSO______030.gci - Mop-up Operation #3:1-2      (.bin file, Ep1, fre.)
8P-GPOP-PSO______031.gci - Mop-up Operation #3:1-1      (.dat file, Ep1, fre.)
8P-GPOP-PSO______032.gci - Mop-up Operation #4:1-2      (.bin file, Ep1, fre.)
8P-GPOP-PSO______033.gci - Mop-up Operation #4:1-1      (.dat file, Ep1, fre.)
8P-GPOP-PSO______034.gci - Pioneer Warehouse:2-2        (.bin file, Ep2, fre.)
8P-GPOP-PSO______035.gci - Pioneer Warehouse:2-1        (.dat file, Ep2, fre.)
8P-GPOP-PSO______036.gci - Rappy's Holiday:1-2          (.bin file, Ep1, fre.)
8P-GPOP-PSO______037.gci - Rappy's Holiday:1-1          (.dat file, Ep1, fre.)
8P-GPOP-PSO______038.gci - Reach for the Dream:2-2      (.bin file, Ep2, fre.)
8P-GPOP-PSO______039.gci - Reach for the Dream:2-1      (.dat file, Ep2, fre.)
8P-GPOP-PSO______040.gci - Seat of the Heart:2-2        (.bin file, Ep2, fre.)
8P-GPOP-PSO______041.gci - Seat of the Heart:2-1        (.dat file, Ep2, fre.)
8P-GPOP-PSO______042.gci - The East Tower:2-2           (.bin file, Ep2, fre.)
8P-GPOP-PSO______043.gci - The East Tower:2-1           (.dat file, Ep2, fre.)
8P-GPOP-PSO______044.gci - The Missing Maracas:1-2      (.bin file, Ep1, fre.)
8P-GPOP-PSO______045.gci - The Missing Maracas:1-1      (.dat file, Ep1, fre.)
8P-GPOP-PSO______046.gci - The Principal's Gift:1-2     (.bin file, Ep1, fre.)
8P-GPOP-PSO______047.gci - The Principal's Gift:1-1     (.dat file, Ep1, fre.)
8P-GPOP-PSO______048.gci - The Tinkerbell's Dog 2:1-2   (.bin file, Ep1, fre.)
8P-GPOP-PSO______049.gci - The Tinkerbell's Dog 2:1-1   (.dat file, Ep1, fre.)
8P-GPOP-PSO______050.gci - The West Tower:2-2           (.bin file, Ep2, fre.)
8P-GPOP-PSO______051.gci - The West Tower:2-1           (.dat file, Ep2, fre.)
8P-GPOP-PSO______052.gci - Today's Rate:1-2             (.bin file, Ep1, fre.)
8P-GPOP-PSO______053.gci - Today's Rate:1-1             (.dat file, Ep1, fre.)
8P-GPOP-PSO______054.gci - Towards the Future:1-2       (.bin file, Ep1, fre.)
8P-GPOP-PSO______055.gci - Towards the Future:1-1       (.dat file, Ep1, fre.)

Note that you must always copy both download quest files (the .bin file and the
.dat file) to your memory card.

All download quest files in this archive are in unencrypted PRS compressed form
and are playable on every PAL copy of the game with the following enabler cheat
code:

PAL Phantasy Star Online Episode I & II
=======================================

Action Replay code format
-------------------------

Download Quests: PRS Compression Enabler [Ralf]
V9EM-QZPN-P7KCD
0U3N-81R8-UVUXB
829P-J73K-XDQ39
TJHT-V175-CV0RA
NEZT-QZEZ-ZBAYN
66NH-MJVP-ZC6WC
X6CC-4BBX-KJ00A
3MV8-A8T3-8DFQG
DC6J-E9QE-RQ8C3
G2HK-N7EM-BJUAF
4NPY-W08W-YDRZH
KBQE-UGX8-02UEN
9F4V-NGCJ-YR844
AK51-UP60-G747Q
8K4W-1KFA-H9X8W
GUMK-4BZZ-VRGD4
WDZ4-HAW6-R6FR8
FH22-MKEH-YKPC3
FXMP-2VFJ-NJPQM
P43R-N3M0-ABR7Z
YBM9-UY5K-9FNWK
623K-39W1-G4PAD
E9FZ-A3QA-YCERP

Gecko/WiiRD code format
-----------------------

Download Quests: PRS Compression Enabler [Ralf]
20218C64 807F0024
0600AFD0 00000034
801CFFF8 28000000
4182000C 38610010
480EE85C 480EE878
7CA802A6 4820E8AD
80610060 80030000
28000000 7CA803A6
4E800020 00000000
040F9838 4BF11798
04218350 4BDF2C99
04218354 41820060
042188CC 4BDF271D
042188D0 41820060
04218EE8 4BDF2101
04218EEC 41820044
E2000001 80008000

